WikiTicks – Cartier und A. Lange & Söhne, nächste Serie

8 einzelne JPG-Dateien, Exportmaß 1200 x 1600 px, weißer Hintergrund.
Aus einer KI-generierten 4x2-Übersicht zugeschnitten und proportional eingepasst;
die Exportgröße ist nicht die native Detailauflösung einer Einzelgenerierung.

- Cartier Panthère, Stahl: cartier-panthere-steel.jpg
- Cartier Crash, Gelbgold: cartier-crash-yellow-gold.jpg
- Cartier Baignoire, Gelbgold: cartier-baignoire-yellow-gold.jpg
- Cartier Drive de Cartier, Stahl: cartier-drive-de-cartier-steel.jpg
- Cartier Tank Française, Stahl: cartier-tank-francaise-steel.jpg
- Cartier Roadster, Stahl: cartier-roadster-steel.jpg
- Cartier Santos-Dumont, Stahl: cartier-santos-dumont-steel.jpg
- A. Lange & Söhne Saxonia Thin, Rotgold: a-lange-soehne-saxonia-thin-rose-gold.jpg

GitHub-Zielordner: assets/watches/
KI-generierte illustrative Darstellungen, keine verifizierten Originalabbildungen.
Insbesondere bei Cartier Crash, Roadster und den Gehäuseformen Referenzdetails
vor Veröffentlichung anhand der Website-Einträge prüfen.
