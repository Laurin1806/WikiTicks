WikiTicks – Patek Philippe und Audemars Piguet

Patek Philippe:
- Nautilus 5811/1G, blaues Zifferblatt
- Nautilus 5711/1A, olivgrünes Zifferblatt
- Aquanaut 5167A, schwarzes Zifferblatt
- Calatrava 6119, helles Zifferblatt
Audemars Piguet:
- Royal Oak 5402ST Jumbo, blaues Zifferblatt
- Royal Oak Offshore 26420, schwarzer Chronograph

JPG, weißer Hintergrund, einzeln zugeschnitten und hochskaliert.
Empfohlener GitHub-Zielordner: assets/watches/
KI-generierte Illustrationen, keine verifizierten exakten Produktabbildungen.
