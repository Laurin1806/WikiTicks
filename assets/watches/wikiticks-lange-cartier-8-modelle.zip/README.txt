WikiTicks – A. Lange & Söhne und Cartier

8 einzelne JPG-Dateien, Exportgröße 1152 x 1536 px, weißer Hintergrund.
Die Dateien wurden aus einer 4x2-KI-generierten Übersicht ausgeschnitten und
proportional auf das Exportmaß vergrößert; die native Detailauflösung ist geringer.

- A. Lange & Söhne Odysseus, blaues Zifferblatt: a-lange-soehne-odysseus-blue.jpg
- A. Lange & Söhne Saxonia, Rotgold: a-lange-soehne-saxonia-rose-gold.jpg
- Cartier Santos, Stahl: cartier-santos-steel-white.jpg
- Cartier Tank Louis, Rotgold: cartier-tank-louis-rose-gold.jpg
- Cartier Ballon Bleu, Stahl: cartier-ballon-bleu-steel.jpg
- Cartier Pasha, Stahl: cartier-pasha-steel.jpg
- Cartier Ronde de Cartier: cartier-ronde-must-de-cartier.jpg
- Cartier Tortue, Gelbgold: cartier-tortue-yellow-gold.jpg

GitHub-Zielordner: assets/watches/
KI-generierte illustrative Darstellungen, keine verifizierten Originalabbildungen.
Bitte Referenz- und Zifferblattdetails vor Veröffentlichung prüfen.
