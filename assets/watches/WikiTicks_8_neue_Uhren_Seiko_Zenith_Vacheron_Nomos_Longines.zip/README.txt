WikiTicks – 8 neue Uhrenmodelle

Einzelbilder: 8 JPGs, 768 x 1024 px, weißer Hintergrund.
Paarbilder: 4 JPGs, je zwei Uhren nebeneinander.
Die Einzelbilder wurden aus einer gemeinsamen KI-generierten Übersicht ausgeschnitten
und 2x hochskaliert. Die tatsächliche Detailauflösung bleibt durch die Quellkachel
begrenzt. Modell-/Referenzdetails vor Veröffentlichung prüfen.

- Seiko Sumo, blau: seiko-sumo-blue.jpg
- Seiko 6139 Pogue, gelb: seiko-6139-pogue-yellow.jpg
- King Seiko: king-seiko-ks.jpg
- Grand Seiko 44GS: grand-seiko-44gs.jpg
- Zenith Pilot Type 20: zenith-pilot-type-20.jpg
- Vacheron Constantin Fiftysix: vacheron-constantin-fiftysix.jpg
- Nomos Ludwig: nomos-ludwig.jpg
- Longines Flagship Heritage: longines-flagship-heritage.jpg

GitHub-Zielordner: assets/watches/
