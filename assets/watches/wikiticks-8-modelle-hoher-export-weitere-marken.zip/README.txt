WikiTicks – weitere Modellbilder, hoher Export

8 einzelne JPG-Dateien, je 1536 x 2048 px, weißer Hintergrund.
Aus einer KI-generierten 4x2-Übersicht einzeln ausgeschnitten und proportional
auf die Exportfläche gesetzt. Die Pixelabmessungen sind erhöht, die native
Detailauflösung bleibt jedoch durch die Quellkachel begrenzt.

- Rolex Sea-Dweller, 126600-Stil: rolex-sea-dweller-126600-black.jpg
- Rolex Milgauss, 116400GV-Stil: rolex-milgauss-116400gv-green.jpg
- Rolex Air-King, 126900-Stil: rolex-air-king-126900-black.jpg
- Omega Speedmaster Professional: omega-speedmaster-professional-black.jpg
- Omega Seamaster Planet Ocean: omega-seamaster-planet-ocean-orange.jpg
- Audemars Piguet Royal Oak Offshore Chronograph: audemars-piguet-royal-oak-offshore-chronograph.jpg
- Breguet Classique, Guilloché-Stil: breguet-classique-guilloche.jpg
- Blancpain Fifty Fathoms: blancpain-fifty-fathoms-black.jpg

GitHub-Zielordner: assets/watches/
KI-generierte Illustrationen; Modell-/Referenzdetails vor Veröffentlichung prüfen.
