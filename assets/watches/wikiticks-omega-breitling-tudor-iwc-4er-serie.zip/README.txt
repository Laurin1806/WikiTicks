WikiTicks – vier Modelle

Enthaltene Einzeldateien:
- Omega Speedmaster Dark Side of the Moon: omega-speedmaster-dark-side-of-the-moon.jpg
- Breitling Premier B01: breitling-premier-b01.jpg
- Tudor Black Bay 54, M79000N: tudor-black-bay-54-m79000n.jpg
- IWC Portofino Automatic: iwc-portofino-automatic.jpg

Exportmaß je Datei: 2048 x 2730 px, JPG, weißer Hintergrund.
Wichtiger Hinweis: Die vier Uhren wurden aus einer KI-generierten 2x2-Komposition
einzeln ausgeschnitten und auf die größere Exportfläche hochskaliert. Die Pixelzahl
ist hoch, die native Detailauflösung bleibt aber durch die ursprüngliche Kachel
begrenzt. Bitte Modell- und Referenzdetails vor Veröffentlichung prüfen.
GitHub-Zielordner: assets/watches/
