WikiTicks – GMT-Master II und Explorer II

Diese fünf Einzelbilder entsprechen den im modelle.json hinterlegten Haupt-/Variantenmodellen:
- GMT-Master II Ref. 126710 Pepsi
- GMT-Master II Ref. 126710BLNR Batman
- GMT-Master Ref. 1675 Pepsi
- Explorer II Ref. 226570 Polar
- Explorer II Ref. 1655 Freccione

JPG, weißer Hintergrund, einzeln zugeschnitten und hochskaliert.
Empfohlener GitHub-Zielordner: assets/watches/
KI-generierte Illustrationen – keine verifizierten exakten Produktabbildungen.
