WikiTicks – Rolex-Korrekturen und weitere fehlende Modelle

8 einzeln zugeschnittene JPG-Dateien, je 1152 x 1536 px, weißer Hintergrund.
Jede Uhr ist separat zugeschnitten; vollständige Gehäuse und Bänder sind im Ausschnitt.

Korrekturen:
- Datejust Stahl/Gold, Champagner-Zifferblatt, Ref. 126233
- Air-King, Ref. 126900
- Day-Date Gelbgold, Champagner-Zifferblatt, Ref. 228238
- Day-Date Platin, eisblaues Zifferblatt (Ref. abhängig von Ausführung)

Weitere Modelle:
- Perpetual 1908, Ref. 52508
- Perpetual 1908, Ref. 52509
- Land-Dweller, Ref. 127334
- Land-Dweller, Ref. 127234

GitHub-Zielordner: assets/watches/
KI-generierte Illustrationen, keine verifizierten Originalabbildungen. Die genaue Referenz der Day-Date-Platinvariante bitte anhand der konkreten Zifferblatt-/Gehäuseausführung prüfen.
