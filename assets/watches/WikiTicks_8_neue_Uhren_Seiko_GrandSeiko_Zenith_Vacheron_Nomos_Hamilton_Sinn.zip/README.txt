WikiTicks – 8 weitere Uhrenmodelle

8 Einzelbilder und 4 Zweier-Bildtafeln, weißer Hintergrund.
Einzelbilder als JPG, Exportgröße 768 x 1024 px.
Die Einzelbilder sind aus einer KI-generierten 4x2-Übersicht ausgeschnitten und
auf die Exportgröße hochskaliert; die tatsächliche Detailauflösung ist durch die
Quellkachel begrenzt. Modell- und Referenzdetails vor Veröffentlichung prüfen.

- Seiko SKX007: seiko-skx007.jpg
- Seiko Presage Cocktail Time: seiko-presage-cocktail-time.jpg
- Grand Seiko White Birch: grand-seiko-white-birch.jpg
- Zenith Defy Skyline: zenith-defy-skyline.jpg
- Vacheron Constantin Historiques 222: vacheron-historiques-222.jpg
- Nomos Tetra: nomos-tetra.jpg
- Hamilton Khaki Field Murph: hamilton-khaki-field-murph.jpg
- Sinn 556 I: sinn-556-i.jpg

GitHub-Zielordner: assets/watches/
Paarbilder liegen unter paarbilder/.
