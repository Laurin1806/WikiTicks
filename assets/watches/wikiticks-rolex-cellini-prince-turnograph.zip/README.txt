WikiTicks – Rolex Cellini, Prince und Turn-O-Graph

3 einzeln zugeschnittene JPG-Dateien aus einer 3er-Bildserie.
Weißer Hintergrund; Originalausschnitte ohne Hochskalierung.

- rolex-cellini-time-cream-dial.jpg – Cellini, klassische Dresswatch
- rolex-prince-brancard-rose-gold.jpg – Prince Brancard, rechteckiges Gehäuse
- rolex-turn-o-graph-116264-black.jpg – Datejust Turn-O-Graph, schwarze Variante

GitHub-Zielordner: assets/watches/
KI-generierte Illustrationen. Die Prince- und Cellini-Varianten sowie die genaue
Turn-O-Graph-Referenz sind illustrativ und nicht als verifizierte Referenzfotos
zu verstehen. Bitte vor Veröffentlichung anhand der Website-Referenzen prüfen.
