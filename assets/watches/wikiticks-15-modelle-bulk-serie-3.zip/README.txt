WikiTicks – Bulk-Serie 3

15 einzelne JPG-Dateien, je 1024 x 1280 px, weißer Hintergrund.
Einzelzuschnitte aus 5x3-Raster, proportional eingepasst; keine Streckung.
Alle Uhren sollen vollständig einschließlich Band/Armband sichtbar sein.

- jaeger-lecoultre-reverso-classic.jpg
- jaeger-lecoultre-polaris-date.jpg
- a-lange-soehne-lange-1.jpg
- a-lange-soehne-zeitwerk.jpg
- a-lange-soehne-datograph.jpg
- panerai-luminor-marina.jpg
- panerai-radiomir.jpg
- seiko-skx007.jpg
- seiko-presage-cocktail-time.jpg
- seiko-astron-gps-solar.jpg
- hublot-big-bang.jpg
- hublot-classic-fusion.jpg
- zenith-chronomaster.jpg
- zenith-defy.jpg
- vacheron-constantin-overseas.jpg

GitHub-Zielordner: assets/watches/
KI-generierte Illustrationen, keine verifizierten Originalabbildungen. Referenzdetails und Zifferblattbeschriftungen bitte vor Veröffentlichung prüfen.
