WikiTicks – Bulk-Serie 2: Modellbilder und überarbeitete Varianten

15 einzelne JPG-Dateien, je 1024 x 1280 px, weißer Hintergrund.
Jede Uhr wurde aus einer eigenen Rasterzelle ausgeschnitten und proportional auf eine einheitliche Bildfläche gesetzt. Keine Bildstreckung.

- rolex-submariner-124060.jpg
- rolex-gmt-master-ii-126710blro-pepsi.jpg
- rolex-daytona-126500ln-panda.jpg
- rolex-explorer-ii-226570-polar.jpg
- rolex-explorer-124270.jpg
- omega-speedmaster-professional-310-30-42-50-01-001.jpg
- omega-seamaster-diver-300m-210-30-42-20.jpg
- patek-philippe-nautilus-5711-1a-blue.jpg
- patek-philippe-aquanaut-5167a.jpg
- audemars-piguet-royal-oak-15510st-blue.jpg
- cartier-tank-louis-cartier.jpg
- iwc-portugieser-chronograph-iw3716.jpg
- breitling-navitimer-b01-43.jpg
- grand-seiko-snowflake-sbga211.jpg
- tag-heuer-monaco-caw211p.jpg

GitHub-Zielordner: assets/watches/
Einige Modellfamilien wurden in früheren Serien bereits bebildert; diese Dateien sind als alternative/aktualisierte Fassungen gedacht und können vorhandene Dateien mit gleichem Namen ersetzen.
KI-generierte Illustrationen, keine verifizierten Originalabbildungen. Referenzdetails und Zifferblattbeschriftungen vor Veröffentlichung prüfen.
