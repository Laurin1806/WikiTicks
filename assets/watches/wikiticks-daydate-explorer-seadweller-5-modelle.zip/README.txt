WikiTicks – Day-Date, Explorer und Sea-Dweller

Day-Date:
- 228238: Gelbgold, champagnerfarbenes Zifferblatt
- Platin-Variante: eisblaues Zifferblatt (als Website-Variante hinterlegt)

Explorer:
- 124270: aktuelle 36-mm-Explorer, schwarzes Zifferblatt

Sea-Dweller:
- 126600: aktuelle 43-mm-Sea-Dweller mit Datum
- 1665: Vintage »Double Red«

JPG, weißer Hintergrund, einzeln zugeschnitten und hochskaliert.
Empfohlener GitHub-Zielordner: assets/watches/
KI-generierte Illustrationen; keine verifizierten exakten Produktabbildungen.
