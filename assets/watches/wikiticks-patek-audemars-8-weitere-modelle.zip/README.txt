WikiTicks – Patek Philippe & Audemars Piguet, Serie 3

8 einzeln zugeschnittene JPG-Dateien, je 1152 x 1536 px, weißer Hintergrund.
Jede Rasterzelle enthält eine vollständige Uhr; die Zuschnitte behalten die gesamte sichtbare Uhr inklusive Band/Armband bei.

Patek Philippe:
- Nautilus 3700/1A (blau)
- Nautilus 3800/1A (blau)
- Nautilus 5711/1A Tiffany-Blau
- Aquanaut 5164A Travel Time
- Aquanaut 5168G Khaki
- World Time 5230G
- Annual Calendar 5396
Audemars Piguet:
- Royal Oak Chronograph 26240ST

Empfohlener GitHub-Zielordner: assets/watches/
KI-generierte Illustrationen, keine verifizierten Produktabbildungen. Referenzdetails und Zifferblattbeschriftungen vor produktivem Einsatz prüfen.
