WikiTicks – Patek Philippe & Audemars Piguet, Serie 4

8 einzeln zugeschnittene JPG-Dateien, je 1152 x 1536 px, weißer Hintergrund.
Jede Datei enthält eine einzelne vollständige Uhr einschließlich Band/Armband.

Patek Philippe:
- Calatrava 6119G
- Calatrava 96
- Ewiger Kalender Chronograph 5270
Audemars Piguet:
- Royal Oak 15510ST (blau)
- Royal Oak Offshore Chronograph 26420
- Royal Oak Ewiger Kalender 26574
- Millenary Tourbillon
- Code 11.59 15210

Empfohlener GitHub-Zielordner: assets/watches/
KI-generierte Illustrationen, keine verifizierten Produktabbildungen. Bitte vor Veröffentlichung auf Referenzdetails prüfen.
