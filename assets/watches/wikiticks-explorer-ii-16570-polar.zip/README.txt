WikiTicks – Rolex Explorer II Ref. 16570 Polar

Datei: rolex-explorer-ii-16570-polar.jpg
Zielordner im Repository: assets/watches/
Darstellung: weißes Polar-Zifferblatt, feste 24-Stunden-Lünette, roter GMT-Zeiger.
KI-generierte Illustration nach der vom Nutzer bereitgestellten Referenzansicht.
