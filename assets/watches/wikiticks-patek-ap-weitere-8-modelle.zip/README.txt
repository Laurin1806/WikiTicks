WikiTicks – Patek Philippe & Audemars Piguet, Serie 2

8 einzelne JPG-Dateien, weißer Hintergrund, hochskaliert.
Alle Uhren sind vollständig innerhalb ihrer jeweiligen Rasterzelle angelegt; Bänder/Armbänder sollen vollständig sichtbar sein.

Patek Philippe:
- World Time 5230
- Annual Calendar 5205
- Golden Ellipse
- Twenty~4
- Perpetual Calendar Chronograph
- Calatrava Pilot Travel Time
Audemars Piguet:
- Code 11.59
- Royal Oak Concept

Empfohlener GitHub-Zielordner: assets/watches/
KI-generierte illustrative Darstellungen; Modell- und Referenzdetails bitte vor produktivem Einsatz gegen die jeweiligen Originalreferenzen prüfen.
