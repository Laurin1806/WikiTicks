WikiTicks – Patek Philippe, Audemars Piguet und IWC

8 einzelne JPG-Dateien, Exportgröße 1200 x 1600 px, weißer Hintergrund.
Aus einer KI-generierten 4x2-Übersicht zugeschnitten; Exportmaß ist nicht die native
Einzelbildauflösung. Referenznummern im Dateinamen bezeichnen Stil-/Modellfamilien,
keine geprüfte exakte Konfiguration. Bitte Details vor Veröffentlichung prüfen.

- Patek Philippe Ewiger Kalender Chronograph, 5270-Stil: patek-philippe-perpetual-calendar-chronograph-5270-rose-gold.jpg
- Patek Philippe Calatrava Pilot Travel Time, 5524G-Stil: patek-philippe-calatrava-pilot-travel-time-5524-blue.jpg
- Audemars Piguet Royal Oak Concept, skelettiert: audemars-piguet-royal-oak-concept-skeleton.jpg
- Audemars Piguet Millenary, Rotgold: audemars-piguet-millenary-rose-gold.jpg
- Audemars Piguet Royal Oak Ewiger Kalender: audemars-piguet-royal-oak-perpetual-calendar.jpg
- IWC Aquatimer, schwarzes Blatt: iwc-aquatimer-black.jpg
- IWC Da Vinci Chronograph, weißes Blatt: iwc-da-vinci-chronograph-white.jpg
- IWC Pilot’s Watch Chronograph, schwarzes Blatt: iwc-pilots-watch-chronograph-black.jpg

GitHub-Zielordner: assets/watches/
KI-generierte Illustrationen, keine verifizierten Originalabbildungen.
