WikiTicks – A. Lange & Söhne und Cartier, Serie 3

8 einzeln zugeschnittene JPG-Dateien, Exportgröße 1200 x 1600 px.
Weißer Hintergrund. Aus einer KI-generierten 4x2-Übersicht zugeschnitten;
Exportgröße ist nicht native Einzelbildauflösung.

- A. Lange & Söhne Lange 1, Rotgold: a-lange-soehne-lange-1-rose-gold.jpg
- A. Lange & Söhne Zeitwerk, Platin-Stil: a-lange-soehne-zeitwerk-platinum.jpg
- A. Lange & Söhne Datograph, Rotgold: a-lange-soehne-datograph-rose-gold.jpg
- Cartier Tank Américaine, Rotgold: cartier-tank-americaine-rose-gold.jpg
- Cartier Tank Chinoise, Gelbgold: cartier-tank-chinoise-yellow-gold.jpg
- Cartier Ronde, skelettiert: cartier-ronde-skeleton-steel.jpg
- Cartier Clé de Cartier, Stahl: cartier-cle-de-cartier-steel.jpg
- Cartier Santos, skelettiert, Rotgold: cartier-santos-skeleton-rose-gold.jpg

GitHub-Zielordner: assets/watches/
KI-generierte Illustrationen, keine verifizierten Produktabbildungen. Bitte Modell- und Referenzdetails vor Veröffentlichung prüfen.
